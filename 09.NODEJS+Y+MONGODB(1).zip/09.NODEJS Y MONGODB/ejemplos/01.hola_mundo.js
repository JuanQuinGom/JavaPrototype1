let nombre = "Fernando";

console.log(`Hola ${nombre}`)